Login integration for your site and the Pantheon control panel
